
In this project we aim to create an tool which can read American Sign Language(ASL) alphabets and translate them into english text
---
dataset used: https://www.kaggle.com/grassknoted/asl-alphabet
---

